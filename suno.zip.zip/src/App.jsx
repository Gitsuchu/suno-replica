import React from "react";
import Typewriter from "./components/Typewriter";
import PlayerCard from "./components/PlayerCard";

export default function App() {
  return (
    <main style={{minHeight: "100vh", background:"#06111a", color:"#fff", fontFamily:"Inter, system-ui, sans-serif", padding:32}}>
      <div style={{maxWidth:1200, margin:"0 auto"}}>
        <header style={{display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:32}}>
          <div style={{display:"flex",alignItems:"center",gap:12}}>
            <div style={{width:36,height:36,borderRadius:18, background:"linear-gradient(90deg,#7c3aed,#fb923c)", display:"flex", alignItems:"center", justifyContent:"center", fontWeight:700}}>S</div>
            <div style={{fontWeight:700}}>Suno Replica</div>
          </div>
          <div>
            <button style={{background:"transparent",border:"1px solid rgba(255,255,255,0.08)",color:"#fff",padding:"8px 14px",borderRadius:999,marginRight:8}}>Sign In</button>
            <button style={{background:"linear-gradient(90deg,#7c3aed,#fb923c)",border:"none",color:"#fff",padding:"8px 14px",borderRadius:999}}>Sign Up</button>
          </div>
        </header>

        <section style={{display:"grid", gridTemplateColumns:"1fr 420px", gap:30, alignItems:"start"}}>
          <div>
            <h1 style={{fontSize:72,lineHeight:1,fontWeight:900,margin:0}}>
              Create audio with<br/>generative AI — <Typewriter words={["instantly","in seconds","with ease"]} />
            </h1>
            <p style={{color:"#cbd5e1", maxWidth:600, marginTop:24}}>Generate music, voices and soundscapes — this view includes the restored player UI on the right.</p>
            <div style={{marginTop:28, display:"flex", gap:12}}>
              <input placeholder="Try: mellow lo-fi guitar with rain" style={{flex:1,padding:"12px 16px",borderRadius:999, border:"1px solid rgba(255,255,255,0.06)", background:"#0b1620", color:"#fff"}}/>
              <button style={{padding:"12px 20px", borderRadius:999, background:"linear-gradient(90deg,#7c3aed,#fb923c)", color:"#fff", border:"none"}}>Generate</button>
            </div>
          </div>

          <aside style={{display:"flex",flexDirection:"column", gap:18}}>
            <PlayerCard title="Starling Echoes" artist="Velvet Orion" src="/sample1.mp3" />
            <PlayerCard title="Sunset Loops" artist="Neon Moth" src="/sample2.mp3" />
          </aside>
        </section>

        <footer style={{marginTop:60, color:"#94a3b8"}}>Player UI restored. Make sure <code>public/sample1.mp3</code> and <code>public/sample2.mp3</code> exist.</footer>
      </div>
    </main>
  );
}
